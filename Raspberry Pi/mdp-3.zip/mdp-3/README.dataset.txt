# mdp > 2022-09-10 6:50pm
https://universe.roboflow.com/object-detection/mdp-afzej

Provided by Roboflow
License: CC BY 4.0

